/*
 * SPDX-License-Identifier:    GPL-2.0+
 */

#ifndef XIL_IO_H           /* prevent circular inclusions */
#define XIL_IO_H

/*
 * This empty file is here because ps7_init_gpl.c exported by hw project
 * has #include "xil_io.h" line.
 */

#endif /* XIL_IO_H */
